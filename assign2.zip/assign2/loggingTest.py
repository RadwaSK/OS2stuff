import logging

logging.basicConfig(filename='log.txt', level=logging.DEBUG)
logging.debug("I'm debugging")
logging.info("I'm just an info")
logging.warning("I'm warning you .. Don't eat my donuts!")
